-- AlterTable
ALTER TABLE `courses` ADD COLUMN `favorite` INTEGER NOT NULL DEFAULT 0;
