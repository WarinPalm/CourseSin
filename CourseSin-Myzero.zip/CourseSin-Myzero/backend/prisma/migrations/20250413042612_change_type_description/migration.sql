-- AlterTable
ALTER TABLE `courses` MODIFY `description` TEXT NULL;
