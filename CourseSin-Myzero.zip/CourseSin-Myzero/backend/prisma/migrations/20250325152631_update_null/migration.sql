-- AlterTable
ALTER TABLE `courses` MODIFY `description` VARCHAR(191) NULL,
    MODIFY `benefit` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `users` MODIFY `picture` VARCHAR(191) NULL;
