-- AlterTable
ALTER TABLE `courses` ADD COLUMN `thumbnail` VARCHAR(191) NULL;
