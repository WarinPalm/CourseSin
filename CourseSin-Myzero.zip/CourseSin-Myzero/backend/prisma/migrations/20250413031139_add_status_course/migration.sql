-- AlterTable
ALTER TABLE `courses` ADD COLUMN `status` BOOLEAN NOT NULL DEFAULT true;
