ก่อนเริ่มรัน backend ให้ทำการ 

npm install

npx prisma migrate dev 

แล้วทำการเข้า folder postman ทำการนำไป import ที่ postman 

API Documents : https://documenter.getpostman.com/view/36305586/2sB2ca5Jgm#613022a9-2d8b-4fb3-9c50-e182bc6f14da
